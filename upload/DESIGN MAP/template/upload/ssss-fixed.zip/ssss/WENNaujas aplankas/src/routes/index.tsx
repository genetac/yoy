import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import streetImg from "@/assets/street.jpg";
import facadeImg from "@/assets/facade.jpg";
import interiorImg from "@/assets/interior.jpg";
import tableImg from "@/assets/table.jpg";
import dishOysters from "@/assets/dish-oysters.jpg";
import dishFoieGras from "@/assets/dish-foiegras.jpg";
import dishTurbot from "@/assets/dish-turbot.jpg";
import dishDuck from "@/assets/dish-duck.jpg";
import dishTruffle from "@/assets/dish-truffle.jpg";
import dishSouffle from "@/assets/dish-souffle.jpg";
import dishChocolate from "@/assets/dish-chocolate.jpg";

export const Route = createFileRoute("/")({
  component: Lumiere,
});

/* ── Rain canvas ── */
function Rain({ intensity = 260 }: { intensity?: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    let raf = 0;
    let w = 0, h = 0;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const drops: { x: number; y: number; l: number; s: number; o: number }[] = [];

    const resize = () => {
      w = canvas.width = window.innerWidth * dpr;
      h = canvas.height = window.innerHeight * dpr;
      canvas.style.width = window.innerWidth + "px";
      canvas.style.height = window.innerHeight + "px";
    };
    resize();
    window.addEventListener("resize", resize);

    for (let i = 0; i < intensity; i++) {
      drops.push({
        x: Math.random() * w,
        y: Math.random() * h,
        l: (10 + Math.random() * 22) * dpr,
        s: (6 + Math.random() * 10) * dpr,
        o: 0.15 + Math.random() * 0.35,
      });
    }

    const tick = () => {
      ctx.clearRect(0, 0, w, h);
      ctx.lineCap = "round";
      for (const d of drops) {
        ctx.strokeStyle = `rgba(220, 210, 190, ${d.o})`;
        ctx.lineWidth = 1.1 * dpr;
        ctx.beginPath();
        ctx.moveTo(d.x, d.y);
        ctx.lineTo(d.x - d.l * 0.15, d.y + d.l);
        ctx.stroke();
        d.y += d.s;
        d.x -= d.s * 0.15;
        if (d.y > h) { d.y = -20; d.x = Math.random() * w; }
      }
      raf = requestAnimationFrame(tick);
    };
    tick();
    return () => { cancelAnimationFrame(raf); window.removeEventListener("resize", resize); };
  }, [intensity]);
  return <canvas ref={ref} className="pointer-events-none absolute inset-0 z-30 mix-blend-screen opacity-70" />;
}

/* ── Fog / mist ── */
function Fog() {
  return (
    <div className="pointer-events-none absolute inset-0 z-20 opacity-60"
      style={{
        background:
          "radial-gradient(ellipse at 30% 70%, rgba(190,160,120,0.18), transparent 55%)," +
          "radial-gradient(ellipse at 70% 60%, rgba(120,110,140,0.22), transparent 60%)," +
          "linear-gradient(to top, rgba(10,8,6,0.65), transparent 40%)",
        filter: "blur(2px)",
      }}
    />
  );
}

/* ── Scroll-driven layered scene ── */
function Lumiere() {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [p, setP] = useState(0); // overall progress 0..1
  const [doorOpen, setDoorOpen] = useState(false);
  const [mouse, setMouse] = useState({ x: 0, y: 0 });
  const [lightbox, setLightbox] = useState<null | { name: string; note: string; price: string; img: string }>(null);

  useEffect(() => {
    const onScroll = () => {
      const el = scrollRef.current;
      if (!el) return;
      const total = el.scrollHeight - window.innerHeight;
      setP(Math.max(0, Math.min(1, window.scrollY / total)));
    };
    const onMove = (e: MouseEvent) => {
      setMouse({
        x: (e.clientX / window.innerWidth - 0.5) * 2,
        y: (e.clientY / window.innerHeight - 0.5) * 2,
      });
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("mousemove", onMove);
    return () => { window.removeEventListener("scroll", onScroll); window.removeEventListener("mousemove", onMove); };
  }, []);

  // stages: intro, door, inside, menu, reviews, table
  const s1 = Math.min(1, p / 0.15);
  const s2 = Math.min(1, Math.max(0, (p - 0.15) / 0.17));
  const s3 = Math.min(1, Math.max(0, (p - 0.32) / 0.18));
  const sM = Math.min(1, Math.max(0, (p - 0.5) / 0.18));
  const sR = Math.min(1, Math.max(0, (p - 0.68) / 0.16));
  const s4 = Math.min(1, Math.max(0, (p - 0.84) / 0.16));

  // auto-open door when close enough
  useEffect(() => { if (s2 > 0.75) setDoorOpen(true); }, [s2]);

  // Close lightbox on Escape
  useEffect(() => {
    if (!lightbox) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setLightbox(null); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [lightbox]);

  return (
    <div ref={scrollRef} className="relative">
      {/* Fixed cinematic viewport */}
      <div className="fixed inset-0 overflow-hidden bg-black">
        {/* Sky glow (deepest layer) */}
        <div
          className="absolute inset-0"
          style={{
            background: "radial-gradient(ellipse at 50% 30%, oklch(0.2 0.04 60) 0%, oklch(0.06 0.01 60) 70%)",
            transform: `scale(${1 + s1 * 0.05}) translate(${mouse.x * -6}px, ${mouse.y * -4}px)`,
          }}
        />

        {/* Street layer — dolly in */}
        <div
          className="absolute inset-0 transition-opacity duration-700"
          style={{
            opacity: 1 - s3 * 0.9,
            transform: `scale(${1.05 + s1 * 0.6 + s2 * 0.4}) translate(${mouse.x * -14}px, ${mouse.y * -8}px)`,
            transformOrigin: "50% 55%",
            filter: `brightness(${0.7 + s2 * 0.3})`,
          }}
        >
          <img
            src={streetImg}
            alt="Rain-soaked cobblestone street at night"
            width={1920}
            height={1280}
            className="h-full w-full object-cover"
          />
          <Fog />
        </div>

        {/* Facade layer — appears mid, dollies through */}
        <div
          className="absolute inset-0"
          style={{
            opacity: s1 * (1 - s3),
            transform: `scale(${0.7 + s1 * 0.5 + s2 * 0.9}) translate(${mouse.x * -22}px, ${mouse.y * -12}px)`,
            transformOrigin: "50% 55%",
          }}
        >
          <div className="relative h-full w-full">
            <img
              src={facadeImg}
              alt="Ornate restaurant facade with brass door and warm windows"
              width={1600}
              height={1600}
              loading="lazy"
              className="mx-auto h-full w-auto max-w-none object-contain"
              style={{ filter: `brightness(${0.9 + s2 * 0.2})` }}
            />
            <div
              className="glow-pulse absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
              style={{
                width: `${20 + s2 * 30}vmin`,
                height: `${28 + s2 * 40}vmin`,
                background: "radial-gradient(ellipse, oklch(0.85 0.18 75 / 0.55), transparent 65%)",
                opacity: doorOpen ? 1 : 0.5 + s2 * 0.4,
                filter: "blur(20px)",
              }}
            />
            <button
              type="button"
              onClick={() => setDoorOpen((v) => !v)}
              aria-label="Open the door"
              className="absolute left-1/2 top-[52%] -translate-x-1/2 -translate-y-1/2 cursor-pointer"
              style={{
                width: "9vmin",
                height: "18vmin",
                background: doorOpen
                  ? "radial-gradient(ellipse, oklch(0.9 0.2 80 / 0.95), oklch(0.7 0.18 60 / 0.6))"
                  : "transparent",
                boxShadow: doorOpen
                  ? "0 0 80px 30px oklch(0.85 0.2 75 / 0.7), inset 0 0 40px oklch(0.95 0.2 80 / 0.6)"
                  : "none",
                transition: "all 900ms cubic-bezier(.2,.7,.2,1)",
                borderRadius: "50% 50% 4px 4px / 40% 40% 4px 4px",
              }}
            />
          </div>
        </div>

        {/* Interior layer */}
        <div
          className="absolute inset-0"
          style={{
            opacity: s3,
            transform: `scale(${0.6 + s3 * 0.7 + s4 * 0.6}) translate(${mouse.x * -18}px, ${mouse.y * -10}px)`,
            transformOrigin: "50% 55%",
          }}
        >
          <img
            src={interiorImg}
            alt="Grand candlelit dining hall with crystal chandeliers"
            width={1920}
            height={1280}
            loading="lazy"
            className="h-full w-full object-cover flicker"
          />
          <div className="absolute inset-0" style={{
            background: "radial-gradient(ellipse at 50% 45%, oklch(0.7 0.18 65 / 0.25), transparent 60%)",
          }} />
        </div>

        {/* Table layer */}
        <div
          className="absolute inset-0"
          style={{
            opacity: s4,
            transform: `scale(${0.85 + s4 * 0.25}) translate(${mouse.x * -8}px, ${mouse.y * -6}px)`,
          }}
        >
          <img
            src={tableImg}
            alt="Candlelit dining table with wine and porcelain"
            width={1920}
            height={1280}
            loading="lazy"
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/40" />
        </div>

        {/* Rain */}
        <div style={{ opacity: 1 - s3 }} className="absolute inset-0 transition-opacity">
          <Rain intensity={220} />
        </div>

        {/* Vignette */}
        <div className="pointer-events-none absolute inset-0 z-40" style={{
          background: "radial-gradient(ellipse at center, transparent 45%, rgba(0,0,0,0.78) 100%)",
        }} />

        {/* Scene copy overlays */}
        <SceneCopy
          p={p} s1={s1} s2={s2} s3={s3} sM={sM} sR={sR} s4={s4}
          doorOpen={doorOpen} onDoor={() => setDoorOpen(true)}
          onOpenDish={(d) => setLightbox(d)}
        />
      </div>

      {/* Lightbox */}
      {lightbox && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/85 backdrop-blur-md p-6 animate-fade-in"
          onClick={() => setLightbox(null)}
          role="dialog"
          aria-modal="true"
          aria-label={lightbox.name}
        >
          <button
            aria-label="Close"
            onClick={() => setLightbox(null)}
            className="absolute right-6 top-6 rounded-full border border-gold/40 px-4 py-2 text-xs uppercase tracking-[0.35em] text-gold hover:bg-gold/10"
          >
            Close ✕
          </button>
          <div
            className="relative flex max-h-[88vh] w-full max-w-4xl flex-col overflow-hidden rounded-2xl border border-gold/25 bg-black/70 md:flex-row"
            style={{ boxShadow: "0 40px 100px -10px rgba(0,0,0,.9), 0 0 0 1px oklch(0.82 0.15 80 / .2)" }}
            onClick={(e) => e.stopPropagation()}
          >
            <img
              src={lightbox.img}
              alt={lightbox.name}
              className="h-64 w-full object-cover md:h-auto md:w-1/2 animate-scale-in"
            />
            <div className="flex flex-col justify-center gap-4 p-8 md:w-1/2">
              <p className="text-[0.6rem] uppercase tracking-[0.5em] text-gold/80">Signature dish</p>
              <h4 className="font-display text-4xl leading-tight text-gold">{lightbox.name}</h4>
              <p className="text-sm italic leading-relaxed text-foreground/70">{lightbox.note}</p>
              <div className="flex items-center gap-3 pt-2">
                <span className="h-px flex-1 bg-gold/25" />
                <span className="font-display text-2xl text-gold">€{lightbox.price}</span>
                <span className="h-px flex-1 bg-gold/25" />
              </div>
              <p className="text-[0.65rem] uppercase tracking-[0.35em] text-foreground/50">
                Plated à la minute · paired with sommelier's choice
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Scroll spacer */}
      <div style={{ height: "700vh" }} />
    </div>
  );
}

/* ── Copy layered on top of the cinematic viewport ── */
function SceneCopy({
  p, s1, s2, s3, sM, sR, s4, doorOpen, onDoor, onOpenDish,
}: {
  p: number; s1: number; s2: number; s3: number; sM: number; sR: number; s4: number;
  doorOpen: boolean; onDoor: () => void;
  onOpenDish: (d: { name: string; note: string; price: string; img: string }) => void;
}) {
  const stage =
    p < 0.15 ? "intro" :
    p < 0.32 ? "door" :
    p < 0.5 ? "inside" :
    p < 0.68 ? "menu" :
    p < 0.84 ? "reviews" : "table";

  const scrollTo = (frac: number) => {
    const total = document.documentElement.scrollHeight - window.innerHeight;
    window.scrollTo({ top: total * frac, behavior: "smooth" });
  };

  return (
    <div className="pointer-events-none absolute inset-0 z-50 flex items-center justify-center px-6">
      {/* Fixed top bar */}
      <div className="absolute inset-x-0 top-0 flex items-center justify-between px-6 py-5 text-[0.65rem] uppercase tracking-[0.35em] text-gold/80 sm:px-10 sm:py-6 sm:text-[0.7rem]">
        <span className="font-display text-lg tracking-[0.4em] text-gold">Lumière</span>
        <div className="pointer-events-auto flex items-center gap-2 sm:gap-4">
          <button onClick={() => scrollTo(0.58)} className="rounded-full border border-gold/25 px-3 py-1.5 tracking-[0.35em] text-gold/85 transition hover:border-gold hover:text-gold sm:px-4">
            Menu
          </button>
          <button onClick={() => scrollTo(0.76)} className="hidden rounded-full border border-gold/25 px-3 py-1.5 tracking-[0.35em] text-gold/85 transition hover:border-gold hover:text-gold sm:inline sm:px-4">
            Reviews
          </button>
          <button onClick={() => scrollTo(0.94)} className="rounded-full px-3 py-1.5 tracking-[0.35em] text-primary-foreground transition hover:brightness-110 sm:px-4" style={{ background: "var(--gradient-gold)" }}>
            Reserve
          </button>
        </div>
      </div>

      {/* Intro copy */}
      <div
        className="max-w-2xl text-center transition-opacity duration-700"
        style={{ opacity: stage === "intro" ? 1 - s1 * 0.4 : 0, transform: `translateY(${s1 * -30}px)` }}
      >
        <p className="mb-4 text-[0.68rem] uppercase tracking-[0.5em] text-gold/80">A fine dining experience</p>
        <h1 className="font-display text-[clamp(3.5rem,10vw,8rem)] leading-[0.95] text-gold">
          Lumière
        </h1>
        <p className="mx-auto mt-6 max-w-md text-sm leading-relaxed text-foreground/70">
          Rain on cobblestones. A brass handle turns. Scroll — and walk in.
        </p>
        <div className="pointer-events-auto mt-8 flex flex-wrap justify-center gap-3">
          <button
            onClick={() => scrollTo(0.58)}
            className="rounded-full border border-gold/40 px-6 py-3 text-xs uppercase tracking-[0.35em] text-gold transition hover:bg-gold/10"
          >
            View Menu
          </button>
          <button
            onClick={() => scrollTo(0.94)}
            className="rounded-full px-6 py-3 text-xs uppercase tracking-[0.35em] text-primary-foreground transition hover:brightness-110"
            style={{ background: "var(--gradient-gold)" }}
          >
            Reserve a Table
          </button>
        </div>
        <div className="mt-8 flex justify-center bob">
          <span className="text-[0.65rem] uppercase tracking-[0.4em] text-gold/60">↓ Or scroll to arrive</span>
        </div>
      </div>

      {/* Door prompt */}
      <div
        className="absolute bottom-24 left-1/2 -translate-x-1/2 text-center transition-opacity duration-700"
        style={{ opacity: stage === "door" ? 1 : 0 }}
      >
        <p className="mb-3 font-display text-3xl text-gold">The Entrance</p>
        <p className="pointer-events-auto text-xs uppercase tracking-[0.4em] text-foreground/60">
          {doorOpen ? "Step inside…" : (
            <button onClick={onDoor} className="cursor-pointer underline-offset-4 hover:text-gold hover:underline">
              Click the door — or keep scrolling
            </button>
          )}
        </p>
      </div>

      {/* Interior */}
      <div
        className="max-w-2xl text-center transition-opacity duration-700"
        style={{ opacity: stage === "inside" ? 1 : 0, transform: `translateY(${(1 - s3) * 30}px)` }}
      >
        <p className="mb-4 text-[0.68rem] uppercase tracking-[0.5em] text-gold/80">Bienvenue</p>
        <h2 className="font-display text-[clamp(2.5rem,7vw,5.5rem)] leading-[0.95] text-gold">
          Your table<br/>is waiting.
        </h2>
        <p className="mx-auto mt-6 max-w-md text-sm leading-relaxed text-foreground/70">
          Chandeliers hum, silverware chimes, a violin somewhere behind the velvet.
        </p>
      </div>

      {/* Menu */}
      <div
        className="pointer-events-auto w-full max-w-2xl transition-all duration-700"
        style={{
          opacity: stage === "menu" ? 1 : 0,
          transform: `translateY(${(1 - sM) * 30}px)`,
          pointerEvents: stage === "menu" ? "auto" : "none",
        }}
      >
        <MenuCard onOpenDish={onOpenDish} />
      </div>

      {/* Reviews */}
      <div
        className="pointer-events-auto w-full max-w-3xl transition-all duration-700"
        style={{
          opacity: stage === "reviews" ? 1 : 0,
          transform: `translateY(${(1 - sR) * 30}px)`,
          pointerEvents: stage === "reviews" ? "auto" : "none",
        }}
      >
        <ReviewsCard />
      </div>

      {/* Booking form */}
      <div
        className="pointer-events-auto w-full max-w-md transition-all duration-700"
        style={{
          opacity: stage === "table" ? 1 : 0,
          transform: `translateY(${(1 - s4) * 40}px)`,
          pointerEvents: stage === "table" ? "auto" : "none",
        }}
      >
        <BookingCard />
      </div>

      {/* Progress ticks */}
      <div className="absolute bottom-6 left-1/2 flex -translate-x-1/2 gap-2">
        {[s1, s2, s3, sM, sR, s4].map((v, i) => (
          <span key={i} className="h-[2px] w-8 rounded-full bg-foreground/15 overflow-hidden">
            <span className="block h-full bg-gold" style={{ width: `${v * 100}%` }} />
          </span>
        ))}
      </div>
    </div>
  );
}

const MENU: { section: string; items: { name: string; note: string; price: string; img: string }[] }[] = [
  {
    section: "Ouvertures",
    items: [
      { name: "Huîtres de Cancale", note: "mignonette, cucumber ice", price: "28", img: dishOysters },
      { name: "Foie Gras au Torchon", note: "quince, brioche", price: "34", img: dishFoieGras },
    ],
  },
  {
    section: "Plats",
    items: [
      { name: "Turbot Rôti", note: "beurre blanc, sea herbs", price: "58", img: dishTurbot },
      { name: "Canard à l'Orange", note: "aged bigarade, endive", price: "62", img: dishDuck },
      { name: "Truffle Tagliolini", note: "black winter truffle, aged parmesan", price: "48", img: dishTruffle },
    ],
  },
  {
    section: "Desserts",
    items: [
      { name: "Soufflé Grand Marnier", note: "vanilla crème anglaise", price: "22", img: dishSouffle },
      { name: "Tarte au Chocolat", note: "smoked salt, olive oil", price: "20", img: dishChocolate },
    ],
  },
];

function MenuCard({ onOpenDish }: { onOpenDish: (d: { name: string; note: string; price: string; img: string }) => void }) {
  return (
    <div
      className="max-h-[80vh] w-full overflow-y-auto rounded-2xl border border-gold/25 bg-black/65 p-6 backdrop-blur-xl sm:p-8"
      style={{ boxShadow: "0 30px 80px -20px rgba(0,0,0,.7), 0 0 0 1px oklch(0.82 0.15 80 / .15)" }}
    >
      <div className="mb-6 text-center">
        <p className="text-[0.65rem] uppercase tracking-[0.5em] text-gold/80">La Carte</p>
        <h3 className="font-display text-3xl text-gold">This Evening</h3>
        <p className="mt-2 text-[0.6rem] uppercase tracking-[0.35em] text-foreground/40">Tap a dish for a closer look</p>
      </div>
      <div className="space-y-7">
        {MENU.map((sec) => (
          <div key={sec.section}>
            <div className="mb-3 flex items-center gap-3">
              <span className="h-px flex-1 bg-gold/20" />
              <p className="text-[0.6rem] uppercase tracking-[0.45em] text-gold/80">{sec.section}</p>
              <span className="h-px flex-1 bg-gold/20" />
            </div>
            <ul className="space-y-3">
              {sec.items.map((it) => (
                <li key={it.name}>
                  <button
                    type="button"
                    onClick={() => onOpenDish(it)}
                    className="group flex w-full items-center gap-4 rounded-xl border border-transparent p-2 text-left transition hover:border-gold/30 hover:bg-gold/5 focus:border-gold/40 focus:outline-none"
                    aria-label={`View ${it.name} up close`}
                  >
                    <div className="relative h-16 w-16 flex-none overflow-hidden rounded-lg ring-1 ring-gold/20 sm:h-20 sm:w-20">
                      <img
                        src={it.img}
                        alt={it.name}
                        width={800}
                        height={800}
                        loading="lazy"
                        className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                      />
                      <span className="pointer-events-none absolute inset-0 flex items-center justify-center bg-black/50 text-[0.55rem] uppercase tracking-[0.3em] text-gold opacity-0 transition-opacity group-hover:opacity-100">
                        Zoom
                      </span>
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-baseline gap-3">
                        <span className="font-display text-lg leading-tight text-foreground transition-colors group-hover:text-gold sm:text-xl">{it.name}</span>
                        <span className="hidden flex-1 border-b border-dashed border-gold/20 sm:block" />
                        <span className="whitespace-nowrap text-sm text-gold">€{it.price}</span>
                      </div>
                      <p className="mt-1 text-[0.75rem] italic leading-snug text-foreground/55">{it.note}</p>
                    </div>
                  </button>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <p className="mt-6 text-center text-[0.6rem] uppercase tracking-[0.4em] text-foreground/40">
        Tasting menu · 7 courses · €165
      </p>
    </div>
  );
}

const REVIEWS: { quote: string; author: string; source: string; rating: number }[] = [
  {
    quote: "A rain-soaked overture leading to the most quietly astonishing dining room in the city. Every course felt like a whispered secret.",
    author: "Élise Marchand",
    source: "Le Figaro Gourmet",
    rating: 5,
  },
  {
    quote: "The turbot alone is worth the pilgrimage. Beurre blanc so pure it tasted like candlelight.",
    author: "James Whitcombe",
    source: "The Financial Times",
    rating: 5,
  },
  {
    quote: "Cinematic, unhurried, precise. Lumière does not serve dinner — it stages an evening.",
    author: "Anaïs Verdier",
    source: "Condé Nast Traveler",
    rating: 5,
  },
  {
    quote: "We came for the soufflé, stayed for the violin. Three hours vanished like breath on a wine glass.",
    author: "Marco & Livia",
    source: "Guest reservation, table 4",
    rating: 5,
  },
];

function Stars({ n }: { n: number }) {
  return (
    <span aria-label={`${n} out of 5`} className="text-gold tracking-[0.3em] text-xs">
      {"★★★★★".slice(0, n)}<span className="text-gold/25">{"★★★★★".slice(n)}</span>
    </span>
  );
}

function ReviewsCard() {
  return (
    <div
      className="w-full rounded-2xl border border-gold/25 bg-black/65 p-5 backdrop-blur-xl sm:p-7"
      style={{ boxShadow: "0 30px 80px -20px rgba(0,0,0,.7), 0 0 0 1px oklch(0.82 0.15 80 / .15)" }}
    >
      <div className="mb-4 text-center">
        <p className="text-[0.62rem] uppercase tracking-[0.5em] text-gold/80">In the Press</p>
        <h3 className="font-display text-2xl text-gold sm:text-3xl">Whispers &amp; Praise</h3>
        <div className="mt-2 flex items-center justify-center gap-3 text-[0.62rem] uppercase tracking-[0.3em] text-foreground/60">
          <Stars n={5} />
          <span>·</span>
          <span>4.9 / 5 · 1,240 guests</span>
        </div>
      </div>
      {/* auto-rows-fr forces both rows to match the SAME height as each
          other (not just each row matching its own tallest card), so the
          2x2 block reads as one aligned unit instead of a ragged grid. */}
      <div className="grid auto-rows-fr gap-3 sm:grid-cols-2">
        {REVIEWS.map((r) => (
          <figure
            key={r.author}
            className="group flex min-h-0 flex-col justify-between rounded-xl border border-gold/15 bg-black/40 p-4 transition hover:border-gold/40 hover:bg-gold/5"
          >
            <div className="mb-2 flex items-center justify-between">
              <Stars n={r.rating} />
              <span className="text-gold/40 font-display text-2xl leading-none">“</span>
            </div>
            {/* line-clamp keeps every quote to the same number of lines
                regardless of source length, so no card ends up with
                extra empty space or forces the others to stretch. */}
            <blockquote className="line-clamp-3 font-display text-sm leading-snug text-foreground/85 sm:text-base">
              {r.quote}
            </blockquote>
            <figcaption className="mt-3 truncate border-t border-gold/15 pt-2 text-[0.6rem] uppercase tracking-[0.25em]">
              <span className="text-gold">{r.author}</span>
              <span className="text-foreground/40"> · {r.source}</span>
            </figcaption>
          </figure>
        ))}
      </div>
      <p className="mt-4 text-center text-[0.58rem] uppercase tracking-[0.4em] text-foreground/40">
        Continue scrolling — your table is next.
      </p>
    </div>
  );
}

function BookingCard() {
  const [sent, setSent] = useState(false);
  return (
    <form
      onSubmit={(e) => { e.preventDefault(); setSent(true); }}
      className="rounded-2xl border border-gold/25 bg-black/55 p-7 backdrop-blur-xl"
      style={{ boxShadow: "0 30px 80px -20px rgba(0,0,0,.7), 0 0 0 1px oklch(0.82 0.15 80 / .15)" }}
    >
      <div className="mb-5 text-center">
        <p className="text-[0.65rem] uppercase tracking-[0.5em] text-gold/80">Reserve</p>
        <h3 className="font-display text-3xl text-gold">This Table</h3>
      </div>

      {sent ? (
        <div className="py-8 text-center">
          <p className="font-display text-2xl text-gold">Merci.</p>
          <p className="mt-2 text-xs uppercase tracking-[0.3em] text-foreground/60">Your candle is lit.</p>
        </div>
      ) : (
        <div className="space-y-3">
          <input
            required
            placeholder="Your name"
            className="w-full rounded-md border border-gold/20 bg-black/40 px-4 py-3 text-sm placeholder:text-foreground/40 focus:border-gold focus:outline-none"
          />
          <div className="grid grid-cols-2 gap-3">
            <select className="rounded-md border border-gold/20 bg-black/40 px-3 py-3 text-sm focus:border-gold focus:outline-none">
              <option>2 guests</option><option>4 guests</option><option>6 guests</option>
            </select>
            <select className="rounded-md border border-gold/20 bg-black/40 px-3 py-3 text-sm focus:border-gold focus:outline-none">
              <option>19:00</option><option>20:00</option><option>21:00</option>
            </select>
          </div>
          <button
            type="submit"
            className="mt-2 w-full rounded-md py-3 text-sm font-medium uppercase tracking-[0.3em] text-primary-foreground transition hover:brightness-110"
            style={{ background: "var(--gradient-gold)" }}
          >
            Reserve the evening
          </button>
          <p className="text-center text-[0.65rem] uppercase tracking-[0.3em] text-foreground/40">
            🕯 · 🍷 · 🍽
          </p>
        </div>
      )}
    </form>
  );
}
